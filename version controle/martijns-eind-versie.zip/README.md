# CLE1-group3-user-guide-website

## Dutch
Voor onze smart device hebben we deze gebruikershandleidingwebsite gemaakt, zodat onze doelgroep gemakkelijk kan navigeren over het doel en het gebruik van het slimme apparaat.



## English
For our, smart device product we made this user guide website so that our target audience can comfortably navigate the purpose and use of the smart device.
